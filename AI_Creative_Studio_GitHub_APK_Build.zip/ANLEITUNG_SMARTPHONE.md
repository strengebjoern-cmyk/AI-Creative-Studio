# APK ohne PC bauen

1. Auf https://github.com ein kostenloses Konto erstellen und anmelden.
2. Neues **privates** Repository erstellen (z. B. `ai-creative-studio`).
3. Den Inhalt dieses Projektordners in das Repository hochladen. Wichtig: `app`, `.github`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties` müssen direkt im Stammverzeichnis liegen. Die versteckte `.github`-Struktur muss erhalten bleiben. Die ZIP-Datei allein hochzuladen reicht nicht.
4. Im Repository **Actions** öffnen. Workflow **Android APK erstellen** auswählen und **Run workflow** ausführen (oder nach einem Push automatisch ausführen lassen).
5. Nach erfolgreichem Lauf den Workflow öffnen und unter **Artifacts** `AI-Creative-Studio-APK` herunterladen. ZIP entpacken; darin liegt `app-debug.apk`.
6. APK auf dem Android-Smartphone öffnen und Installation aus dieser Quelle zulassen.

Hinweis: Der Workflow ist vorbereitet, aber hier nicht auf GitHub ausgeführt oder als APK verifiziert. Bei einem roten Build-Fehler die Fehlermeldung zur Diagnose senden. Die App enthält noch keine vollständige Bild- und Videogenerierung.
